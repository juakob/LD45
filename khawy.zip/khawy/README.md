# khawy
Kha game framework inspire in haxeflixel but with a more flexible design (aggregation instead of inheritance). 
Also is power by the awesome Kha engine that enables khawy to run in almost any device and it makes it super fast.

current example(under work)
https://juakob.github.io/LD45/
source: https://github.com/juakob/LD45
